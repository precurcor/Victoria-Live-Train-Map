# Layout export — NOT manufacturing ready

Victoria rail map

1616 map LEDs; 139 generated 10 uF grouped decoupling capacitors; 117 retained controller/power/USB footprints.

Open KiCad/Melbourne-Live-Train-Map.kicad_pro in KiCad 9+.

The existing main and USB schematics are preserved. LED and decoupling sheets are regenerated and linked to PCB footprints by matching UUID paths. Data chains, supply nets and ground are real nets, not silk drawings. All copper tracks, vias and fills from the original board are deliberately removed: arbitrary relocation makes them invalid. Route and validate in KiCad. The source MCU/RF/power topology is unchanged, but its placement and RF geometry must be reviewed; original routing/antenna copper was NOT retained.

OLED/encoder items without an exact part are drawings on Dwgs.User only. There is no guessed FPC pinout, OLED charge-pump circuit, encoder debounce or GPIO assignment. Imported custom footprints have unconnected pads until integrated in the schematic. Complete these circuits before ordering.

The source schematic instances retain the upstream project name to keep hierarchy identity. Additional footprint libraries may be needed when editing/updating the inherited circuit from schematic. Footprint geometry already exists inside the PCB. The source project's external 3D model paths are omitted.

Automatic capacitor placement is provisional. Grouping is inherited practice, not a validated decoupling/power design. Review current, voltage drop, connectors, protection, capacitor spacing and supply-domain assignment for the larger board.

Firmware/backend: manifest and header are integration inputs, not automatic modifications of your other forks. Old block numbers are retained for surviving original LEDs, but chain indexes can change. New intermediate LEDs need real geographic block/transition definitions; canvas coordinates must never be treated as GPS. Saved timetable arrays must also be regenerated before using timetable mode with a changed layout.

Validation
- ERROR: 19 LED pairs are closer than 1.75 mm. Review pad/courtyard clearance.
- WARNING: Bare OLED · part pending: mechanical reservation only; exact part, pads and interface circuitry are not assigned.
- WARNING: Push rotary encoder · part pending: mechanical reservation only; exact part, pads and interface circuitry are not assigned.
- WARNING: 1 stations have no source GTFS identity; assign verified feed IDs before live integration.
- WARNING: 574 new LED blocks need geographic/backend mapping. Screen positions are not GPS coordinates.
- INFO: PCB exports preserve the controller circuit but remove all copper routing. Complete routing and run KiCad ERC/DRC.

Native KiCad loading/ERC/DRC has not been verified in the build environment. Run tools/validate-kicad.py from the program source on a machine with KiCad installed.
